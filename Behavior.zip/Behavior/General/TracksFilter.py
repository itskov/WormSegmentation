import pandas as pd


def filterTracksForAnalyses(tracks, minSteps=0, minDistance=0):
    newTracks = [track for track in tracks if track.getMaxDistTravelled() >= minDistance and
                 track._trackCords.shape[0] >= minSteps]

    return newTracks



import numpy as np
#DEBUG
from Behavior.Visualizers.OccupVisualizer import OccupVisualizer


def subset_track(t, positions):
    t._trackCords = t._trackCords[positions, :]
    t._trackFrames = t._trackFrames[positions]
    t._tracksSteps = t._tracksSteps[positions, :]
    t._tracksSpeeds = t._tracksSpeeds[positions]
    t._tracksReversals = t._tracksReversals[positions]

    return t


def seive_tracks(exp):
    SMALL_PROP = 0.2
    BIG_PROP = 1 - SMALL_PROP
    FRAMES = 4500
    ANGLE = np.pi / 3

    small_radius = (SMALL_PROP) * exp._scale
    big_radius = (BIG_PROP) * exp._scale

    # Getting the tracks.
    tracks = exp._tracks
    good_tracks = np.array([])

    # horizontal line
    horiz_line = np.array(exp._regionsOfInterest['startReg']['pos']) - np.array(exp._regionsOfInterest['endReg']['pos'])
    horiz_line /= np.linalg.norm(horiz_line)

    # Perp line
    perp_line = np.ones((2,))
    perp_line[0] = -horiz_line[1] / horiz_line[0]
    perp_line /= np.linalg.norm(perp_line)

    # New basis
    new_basis = np.array([perp_line, horiz_line]).T
    trans = np.linalg.inv(new_basis)
    new_end_point = np.matmul(trans, exp._regionsOfInterest['endReg']['pos'])

    newTracks = []

    for i, t in enumerate(tracks):

        print('Gone over track:%d' % (i,))

        # Filter in time.
        if t._trackCords.shape[0] < 50:
            continue

        if t.getMaxDistTravelled() < 75:
            continue

        # First, Trimming the track.
        t = t.trimTrack(FRAMES)

        # Check if there are any coordinates left.
        if t == None or t._trackCords.shape[0] == 0:
            continue

        # Sieving by position
        distances = np.linalg.norm(t._trackCords - exp._regionsOfInterest['endReg']['pos'], axis=1)
        t = subset_track(t, (distances > small_radius))

        if t._trackCords.shape[0] == 0:
            continue


        distances = np.linalg.norm(t._trackCords - exp._regionsOfInterest['endReg']['pos'], axis=1)
        t = subset_track(t, (distances < big_radius))

        if t._trackCords.shape[0] == 0:
            continue

        newCords = np.matmul(trans, t._trackCords.T)
        newCords = newCords.T



        y_boundaries = (newCords[:, 1] - np.array(new_end_point[1])) * np.tan(ANGLE)
        t = subset_track(t, np.abs(newCords[:, 0] - np.array(new_end_point[0])) < y_boundaries)
        if t._trackCords.shape[0] == 0:
            continue

        newTracks.append(t)


    from copy import deepcopy
    exp._cap = None
    exp._tracks = None
    new_exp = deepcopy(exp)
    new_exp.initialize(tracks=np.array(newTracks))
    new_exp ._tracks = np.array(newTracks)
    return new_exp


def exp_to_dataframe(exp):
    df = pd.DataFrame(columns=["Frame", "CordX", "CordY", "Distance", "StepSize", "Angle"])
    for t in exp._tracks:
        frames = t._trackFrames
        cords_x = t._trackCords[:, 1]
        cords_y = t._trackCords[:, 0]
        distances = t.getDistances(exp._regionsOfInterest['endReg']['pos'])
        stepSizes = t._tracksSpeeds
        angles = t.getAngles(exp._regionsOfInterest['endReg']['pos'])

        current_df = pd.DataFrame({"Frame" : frames,
                                   "CordX" : cords_x,
                                   "CordY" : cords_y,
                                   "Distance" : distances,
                                   "StepSize" : stepSizes,
                                   "Angle" : angles})
        current_df = current_df.dropna()
        current_df.Angle = current_df.Angle.astype(np.float64)


        df = df.append(current_df, ignore_index=True)

        pass;


    return df


def main():
    import seaborn as sns

    exp = np.load('/home/itskov/Temp/behav/08-Jan-2020/TPH_1_ATR_TRAIN_70M_NO_IAA3x5.avi_13.05.52/exp.npy')[0]
    exp = seive_tracks(exp)
    df = exp_to_dataframe(exp)
    pass


if __name__ == "__main__":
    main()
